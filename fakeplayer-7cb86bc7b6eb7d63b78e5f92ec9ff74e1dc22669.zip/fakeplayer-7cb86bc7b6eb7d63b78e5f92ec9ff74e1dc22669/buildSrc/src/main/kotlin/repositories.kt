const val SNAPSHOTS = "https://oss.sonatype.org/content/repositories/snapshots/"

const val SPONGEPOWERED = "https://repo.spongepowered.org/maven/"

const val JITPACK = "https://jitpack.io/"

const val PAPERMC = "https://papermc.io/repo/repository/maven-public/"

const val CODEMC = "https://repo.codemc.org/repository/maven-public/"

const val CODEMC_NMS = "https://repo.codemc.org/repository/nms/"

const val MINECRAFT = "https://libraries.minecraft.net"

const val OPENCOLLAB = "https://repo.opencollab.dev/maven-releases/"
