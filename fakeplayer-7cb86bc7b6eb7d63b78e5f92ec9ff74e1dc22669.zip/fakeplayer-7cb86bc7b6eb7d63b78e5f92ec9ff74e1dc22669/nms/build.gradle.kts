subprojects {
  dependencies {
    compileOnly(project(":api"))
  }
}
