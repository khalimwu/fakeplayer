/**
 * the package that contains api classes for FakePlayer plugin.
 */
package io.github.portlek.fakeplayer.api;
