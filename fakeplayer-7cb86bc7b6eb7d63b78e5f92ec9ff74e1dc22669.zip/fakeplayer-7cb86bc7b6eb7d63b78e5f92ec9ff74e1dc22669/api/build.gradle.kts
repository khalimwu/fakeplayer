dependencies {
  compileOnly(paperApiLibrary)
  compileOnly(configurateJacksonLibrary)
}
